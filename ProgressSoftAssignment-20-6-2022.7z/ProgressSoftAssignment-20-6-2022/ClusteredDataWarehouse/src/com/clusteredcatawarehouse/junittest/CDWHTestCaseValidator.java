package com.clusteredcatawarehouse.junittest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.clusteredcatawarehouse.functional.CDWHUtility;
import com.clusteredcatawarehouse.functional.CDWHValidator;
import com.clusteredcatawarehouse.functional.DealDetails;

public class CDWHTestCaseValidator {
	@Before
	public void initDataBase() {
		// Here we can create the moc for the DB connection and its related objects to
		// test the connections, but here I'm interested in tested a simple validation
		// cases
	}

	@Test
	public void testEmptyParamter() {
		DealDetails dealDetails = new DealDetails("WRG86VK", "", "USD", 23.781);
		assertEquals(CDWHValidator.isValidDeal(dealDetails), false);
	}

	@Test
	public void testInvalidAmount() {
		// Suppose the user entered "34.78O" in amount field.
		assertEquals(CDWHUtility.isEmpty(CDWHValidator.isValidAmount("34.78O")), false);
	}

	@Test
	public void testIsPositiveInteger() {
		assertEquals(CDWHUtility.isPositiveInteger("ab"), false);
		assertEquals(CDWHUtility.isPositiveInteger("0.1"), false);
		assertTrue(CDWHUtility.isPositiveInteger("1"));
		assertTrue(CDWHUtility.isPositiveInteger("+12"));
	}

	@Test
	public void testIsPositiveDecimal() {
		assertEquals(CDWHUtility.isPositiveDecimal("ab"), false);
		assertEquals(CDWHUtility.isPositiveDecimal("-0.132213"), false);
		assertTrue(CDWHUtility.isPositiveDecimal("0.1"));
		assertTrue(CDWHUtility.isPositiveDecimal("+12"));
	}
}