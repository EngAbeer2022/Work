package com.clusteredcatawarehouse.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.clusteredcatawarehouse.functional.CDWHException;

public class CDWHConnectionPool {
	private List<Connection> availableConnections = new ArrayList<Connection>();
	private static Logger logger = Logger.getLogger(CDWHConnectionPool.class);

	public CDWHConnectionPool() {
		try {
			logger.info("CDWHConnectionPool initialization started.");
			initializeConnectionPool();
			logger.info("CDWHConnectionPool initialization ended successfully.");
		} catch (CDWHException e) {
			logger.error("Failed while initialzing - CDWHCOnnectionPool");
		}
	}

	private void initializeConnectionPool() throws CDWHException {
		DataBaseProperty properties = new DataBaseProperty();
		while (!checkIfConnectionPoolIsFull(properties)) {
			availableConnections.add(createNewConnectionForPool(properties));
		}
	}

	private synchronized boolean checkIfConnectionPoolIsFull(DataBaseProperty properties) {
		final int MAX_POOL_SIZE = Integer.valueOf(properties.getMaximumNumberOfConnections());
		if (availableConnections.size() < MAX_POOL_SIZE) {
			return false;
		}

		logger.info("CDWHConnectionPool is full");
		return true;
	}

	private Connection createNewConnectionForPool(DataBaseProperty properties) throws CDWHException {
		try {
			logger.info("CDWHConnectionPool - start creating new connection.");
			Class.forName(properties.getDbDriverClass());

			Connection connection = (Connection) DriverManager.getConnection(properties.getDbConnUrl(),
					properties.getDbUserName(), properties.getDbPassword());
			logger.info("CDWHConnectionPool - new connection created successfully.");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			logger.info("CDWHConnectionPool - Failed while creating new connection.");
			throw new CDWHException(e.getMessage());
		}
	}

	public synchronized Connection getConnection() {
		Connection connection = null;
		if (availableConnections.size() > 0) {
			connection = (Connection) availableConnections.get(0);
			availableConnections.remove(0);
		}
		logger.info("CDWHConnectionPool - get connection form pool done successfully.");
		return connection;
	}

	public synchronized void freeConnection(Connection connection) {
		availableConnections.add(connection);
		logger.info("CDWHConnectionPool - connection return to its pool successfully.");
	}
}
