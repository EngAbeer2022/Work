package com.clusteredcatawarehouse.database;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.clusteredcatawarehouse.functional.CDWHException;

public class DataBaseProperty {
	public static Logger logger = Logger.getLogger(DataBaseProperty.class);

	private String dbDriverClass;
	private String dbConnUrl;
	private String dbUserName;
	private String dbPassword;
	private String maximumNumberOfConnections;

	DataBaseProperty() {
		try {
			initDatsBasePros();
		} catch (CDWHException e) {
			logger.info("Failed while initialzing data base properties");
		}
	}

	private void initDatsBasePros() throws CDWHException {
		try {
			logger.info("Start init database properties");
			InputStream stream = DataBaseProperty.class.getClassLoader()//
					.getResourceAsStream("/DatabaseConfig.properties");
			Properties properties = new Properties();
			properties.load(stream);

			// Get each property value.
			setDbDriverClass(properties.getProperty("cdwh_db.driver.class"));
			setDbConnUrl(properties.getProperty("cdwh_db.conn.url"));
			setDbUserName(properties.getProperty("cdwh_db.username"));
			setDbPassword(properties.getProperty("cdwh_db.password"));
			setMaximumNumberOfConnections(properties.getProperty("cdwh_db.maximumnumberofconections"));

			logger.info("Database properties initialized successfully");
		} catch (IOException e) {
			throw new CDWHException(e.getMessage());
		}
	}

	public String getDbDriverClass() {
		return dbDriverClass;
	}

	private void setDbDriverClass(String dbDriverClass) {
		this.dbDriverClass = dbDriverClass;
	}

	public String getDbConnUrl() {
		return dbConnUrl;
	}

	private void setDbConnUrl(String dbConnUrl) {
		this.dbConnUrl = dbConnUrl;
	}

	public String getDbUserName() {
		return dbUserName;
	}

	private void setDbUserName(String dbUserName) {
		this.dbUserName = dbUserName;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	private void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	public String getMaximumNumberOfConnections() {
		return maximumNumberOfConnections;
	}

	private void setMaximumNumberOfConnections(String maximumNumberOfConnections) {
		this.maximumNumberOfConnections = maximumNumberOfConnections;
	}

}