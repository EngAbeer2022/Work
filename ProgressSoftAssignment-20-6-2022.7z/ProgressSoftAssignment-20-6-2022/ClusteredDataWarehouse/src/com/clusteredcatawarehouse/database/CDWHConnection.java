package com.clusteredcatawarehouse.database;

import java.sql.Connection;

public class CDWHConnection {
	static CDWHConnectionPool pool = new CDWHConnectionPool();

	public static Connection getConnection() {
		return pool.getConnection();
	}

	public static void freeConnection(Connection connection) {
		pool.freeConnection(connection);
	}
}
