package com.clusteredcatawarehouse.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.clusteredcatawarehouse.functional.CDWHDataBaseQueryGenerator;
import com.clusteredcatawarehouse.functional.CDWHException;
import com.clusteredcatawarehouse.functional.CDWHUtility;
import com.clusteredcatawarehouse.functional.CDWHValidator;
import com.clusteredcatawarehouse.functional.DealDetails;

/**
 * Servlet implementation class ClusteredDataWarehouse
 */
@WebServlet("/ClusteredDataWarehouse")
public class ClusteredDataWarehouse extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static Logger logger = Logger.getLogger(ClusteredDataWarehouse.class);
	private boolean isDealExits = false;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ClusteredDataWarehouse() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		logger.info("ClusteredDataWarehouseServelt - Start checking if deal is exits.");
		String dealUniqueID = request.getParameter("DealID");
		try {
			isDealExits = CDWHUtility.isDealExits(dealUniqueID);
		} catch (SQLException e) {
			logger.info("ClusteredDataWarehouseServelt - Failed while checking if deal exits - " + e.getMessage());
			HttpSession session = request.getSession();
			session.setAttribute("ErrorMessage",
					"Failed while checking if deal exits, Please press 'Go Back' to try again");
			response.sendRedirect("loginError.jsp");
			return;
		}

		logger.info("ClusteredDataWarehouseServelt - Checking if deal is exits done successfully.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String dealUniqueID = request.getParameter("DealID");
			String fromCurrency = request.getParameter("FromCurrency");
			String toCurrency = request.getParameter("ToCurrency");
			String amountString = request.getParameter("DealAmount");

			String error = CDWHValidator.isValidAmount(amountString);
			if (!CDWHUtility.isEmpty(error)) {
				HttpSession session = request.getSession();
				session.setAttribute("ErrorMessage", error + ", Please press 'Go Back' to try again");
				response.sendRedirect("loginError.jsp");
				return;
			}

			Double amount = Double.valueOf(amountString);

			DealDetails dealDetails;
			dealDetails = new DealDetails(dealUniqueID, fromCurrency, toCurrency, amount);

			String errorMessage = CDWHValidator.isValidDealDetails(dealDetails);
			if (!CDWHUtility.isEmpty(errorMessage)) {
				HttpSession session = request.getSession();
				session.setAttribute("ErrorMessage", errorMessage + ", Please press 'Go Back' to try again");
				response.sendRedirect("loginError.jsp");
				return;
			}

			if (isDealExits) {
				HttpSession session = request.getSession();
				session.setAttribute("ErrorMessage", "Deal already exits, Please press 'Go Back' to try again");
				response.sendRedirect("loginError.jsp");
				return;
			}

			// Inert new deal details:
			CDWHDataBaseQueryGenerator.insert("DealDetails", dealDetails);

		} catch (SQLException e) {
			logger.error(e.getMessage());
			HttpSession session = request.getSession();
			session.setAttribute("ErrorMessage", "Failed while inserting new deal details - " + e.getMessage());
			response.sendRedirect("loginError.jsp");
		}
	}
}