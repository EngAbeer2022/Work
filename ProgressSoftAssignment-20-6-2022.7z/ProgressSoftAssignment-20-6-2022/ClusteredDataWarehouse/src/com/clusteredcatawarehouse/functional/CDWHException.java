package com.clusteredcatawarehouse.functional;

public class CDWHException extends Exception {
	public CDWHException(String errorMessage) {
		super(errorMessage);
	}
}
