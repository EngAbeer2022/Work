package com.clusteredcatawarehouse.functional;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import com.clusteredcatawarehouse.database.CDWHConnection;

/**
 * This class can also contains all SQL statements including joins and etc
 * operation but its simple generator demo according to our needs till now
 */
public class CDWHDataBaseQueryGenerator {
	private static Logger logger = Logger.getLogger(CDWHDataBaseQueryGenerator.class);

	public static List<DealDetails> select(String tableName, String[] columns, String whereClause, String joinPart)
			throws CDWHException {
		List<DealDetails> deals = new LinkedList<DealDetails>();
		return deals;
	}

	public static List<DealDetails> select(String tableName, String whereClause) throws SQLException {
		List<DealDetails> deals = new LinkedList<DealDetails>();
		logger.info("CDWHDataBaseQueryGenerator - Start select operation.");
		Connection connection = CDWHConnection.getConnection();
		Statement statement = connection.createStatement();

		String query = "select * from " + tableName + " WHERE " + whereClause;
		ResultSet resultSet = statement.executeQuery(query);
		while (resultSet.next()) {
			DealDetails dealDetails = new DealDetails(resultSet.getString(1), resultSet.getString(2),
					resultSet.getString(3), resultSet.getDouble(4));
			if (CDWHUtility.isNullDeal(dealDetails)) {
				continue;
			}

			deals.add(dealDetails);
		}

		connection.close();
		CDWHConnection.freeConnection(connection);
		logger.info("CDWHDataBaseQueryGenerator - retrive data from select successfully.");
		return deals;
	}

	// Also here I can create many dynamic signature passing columns & values but I
	// will handle only my case
	public static void insert(String tableName, DealDetails dealDetails) throws SQLException {
		logger.info("CDWHDataBaseQueryGenerator - Start insert operation.");
		String query = "INSERT INTO " + tableName + " VALUES ('" + dealDetails.getDealUniqueID() + "' , '"
				+ dealDetails.getFromCurrency() + "' , '" + dealDetails.getToCurrency() + "' , "
				+ dealDetails.getAmount() + ")";

		Connection connection = CDWHConnection.getConnection();
		Statement statement = connection.createStatement();

		statement.executeUpdate(query);
		connection.close();
		CDWHConnection.freeConnection(connection);
		logger.info("CDWHDataBaseQueryGenerator - Insert new deal done successfully.");
	}
}
