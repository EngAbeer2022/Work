package com.clusteredcatawarehouse.functional;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CDWHUtility {
	public static boolean isEmpty(String word) {
		if (word == null || "null".equalsIgnoreCase(word.trim()) || word.trim().equals("")) {
			return true;
		}

		return false;
	}

	public static boolean isZeroAmount(Double amount) {
		if (amount == null || amount == 0) {
			return true;
		}

		return false;
	}

	public static boolean isOnlyNumbers(String amountAsString) {
		// Regex to check string contains only digits
		String regex = "\\\\d+(\\\\.\\\\d+)*";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(amountAsString);
		return m.matches();
	}

	public static boolean isMatch(String regex, String amountAsString) {
		if (amountAsString == null || amountAsString.trim().equals("")) {
			return false;
		}
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(amountAsString);
		return matcher.matches();
	}

	public static boolean isPositiveInteger(String orginal) {
		return isMatch("^\\+{0,1}[1-9]\\d*", orginal);
	}

	public static boolean isDecimal(String orginal) {
		return isMatch("\\+{0,1}[0]\\.[1-9]*|\\+{0,1}[1-9]\\d*\\.\\d*", orginal);
	}

	public static boolean isZeroStringAmount(String amountAsString) {
		if (!isPositiveDecimal(amountAsString)) {
			return false;
		}

		Double amount = Double.valueOf(amountAsString);
		if (amount == null || amount == 0) {
			return true;
		}

		return false;
	}

	public static boolean isPositiveDecimal(String amountAsString) {
		return isPositiveInteger(amountAsString) || isDecimal(amountAsString);
	}

	public static boolean isNullDeal(DealDetails dealDetails) {
		if (isEmpty(dealDetails.getDealUniqueID()) && isEmpty(dealDetails.getFromCurrency())
				&& isEmpty(dealDetails.getToCurrency()) && isZeroAmount(dealDetails.getAmount())) {
			return true;
		}

		return false;
	}

	public static boolean isDealExits(String dealUniqueID) throws SQLException {
		List<DealDetails> returnedData = CDWHDataBaseQueryGenerator.select("DealDetails",
				"DealUniqueId = " + dealUniqueID);
		return returnedData.size() > 0;
	}
}
