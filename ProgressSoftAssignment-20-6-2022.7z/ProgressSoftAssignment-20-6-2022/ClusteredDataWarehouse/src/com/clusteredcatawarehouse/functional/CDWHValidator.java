package com.clusteredcatawarehouse.functional;

public class CDWHValidator {

	public static String isValidAmount(String amountAsString) {
		if (CDWHUtility.isEmpty(amountAsString)) {
			return "Invalid Request, Deal Amount - Cannot be empty";
		}

		if (!CDWHUtility.isPositiveDecimal(amountAsString)) {
			return "Invalid Request, Deal Amount - Should be positive decimal/integer value";
		}

		if (CDWHUtility.isZeroAmount(Double.valueOf(amountAsString))) {
			return "Invalid Request, Deal Amount - Cannot be Zero";
		}

		return "";
	}

	public static String isValidDealDetails(DealDetails dealDetails) {
		// Check if all fields are provided:
		if (CDWHUtility.isEmpty(dealDetails.getDealUniqueID())) {
			return "Invalid Request, Deal Unique ID - Cannot be empty";
		}

		if (CDWHUtility.isEmpty(dealDetails.getFromCurrency())) {
			return "Invalid Request, Deal From Currency - Cannot be empty";
		}

		if (CDWHUtility.isEmpty(dealDetails.getToCurrency())) {
			return "Invalid Request, Deal To Currency - Cannot be empty";
		}

		if (CDWHUtility.isZeroAmount(dealDetails.getAmount())) {
			return "Invalid Request, Deal Amount - Cannot be empty";
		}

		return "";
	}

	public static boolean isValidDeal(DealDetails dealDetails) {
		if (CDWHUtility.isEmpty(isValidDealDetails(dealDetails))) {
			return true;
		}

		return false;
	}
}
