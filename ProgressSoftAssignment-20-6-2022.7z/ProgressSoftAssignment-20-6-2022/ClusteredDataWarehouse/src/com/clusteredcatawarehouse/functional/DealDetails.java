package com.clusteredcatawarehouse.functional;

public class DealDetails {
	private String dealUniqueID;
	private String fromCurrency;
	private String toCurrency;
	private Double amount;

	public DealDetails(String dealUniqueID, String fromCurrency, String toCurrency, Double amount) {
		setDealUniqueID(dealUniqueID);
		setFromCurrency(fromCurrency);
		setToCurrency(toCurrency);
		setAmount(amount);
	}

	public String getDealUniqueID() {
		return dealUniqueID;
	}

	private void setDealUniqueID(String dealUniqueID) {
		this.dealUniqueID = dealUniqueID;
	}

	public String getFromCurrency() {
		return fromCurrency;
	}

	private void setFromCurrency(String fromCurrency) {
		this.fromCurrency = fromCurrency;
	}

	public String getToCurrency() {
		return toCurrency;
	}

	private void setToCurrency(String toCurrency) {
		this.toCurrency = toCurrency;
	}

	public Double getAmount() {
		return amount;
	}

	private void setAmount(Double amount) {
		this.amount = amount;
	}
}
